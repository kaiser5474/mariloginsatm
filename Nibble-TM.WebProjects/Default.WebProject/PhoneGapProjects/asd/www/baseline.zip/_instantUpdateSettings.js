function _instantUpdateSettings() {
return {
	"baseLineGUID": "282bfd2627f54f5fb18ee6aef9b3b5a5",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": "Please wait while the app is prepared for first-time use."
};
}