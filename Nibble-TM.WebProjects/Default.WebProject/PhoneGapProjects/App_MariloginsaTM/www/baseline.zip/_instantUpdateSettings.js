function _instantUpdateSettings() {
return {
	"baseLineGUID": "d6086b74302d4028a837d1bbcb9faf86",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": "Prueba"
};
}