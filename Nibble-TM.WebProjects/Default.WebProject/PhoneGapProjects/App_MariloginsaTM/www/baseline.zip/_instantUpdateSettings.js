function _instantUpdateSettings() {
return {
	"baseLineGUID": "5f473969b09b44cda8babb000749290b",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": "Prueba"
};
}